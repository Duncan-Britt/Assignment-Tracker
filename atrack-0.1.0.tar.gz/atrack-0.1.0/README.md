# Assignment-Tracker
Commandline Todo-list app for school work.

Compile in root directory with 
```clang -lstdc++ -std=c++11 -o bin/main src/main.cpp src/interface.cpp src/tracker.cpp src/assignment.cpp``` 
or 
```g++ -lstdc++ -std=c++11 -o bin/main src/main.cpp src/interface.cpp src/tracker.cpp src/assignment.cpp```

Execute ```bin/main``` in root directory to run.